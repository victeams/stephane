import React from 'react';
import GameBoy from './components/GameBoy';

function App() {
  return <GameBoy />;
}

export default App;